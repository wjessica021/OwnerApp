// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getFirestore } from "firebase/firestore";

// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyC2_tZhfvGuRJe1jr_pM1TgSX7fyhgwh3A",
//   authDomain: "ownergroup2-3e700.firebaseapp.com",
//   projectId: "ownergroup2-3e700",
//   storageBucket: "ownergroup2-3e700.appspot.com",
//   messagingSenderId: "100126442489",
//   appId: "1:100126442489:web:59823837dd4278d57df328"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);

// // Initialize Firestore
// const firestore = getFirestore(app);

// export default firestore;

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, initializeAuth, getReactNativePersistence } from "firebase/auth";
import AsyncStorage from '@react-native-async-storage/async-storage'; // Import AsyncStorage

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC2_tZhfvGuRJe1jr_pM1TgSX7fyhgwh3A",
  authDomain: "ownergroup2-3e700.firebaseapp.com",
  projectId: "ownergroup2-3e700",
  storageBucket: "ownergroup2-3e700.appspot.com",
  messagingSenderId: "100126442489",
  appId: "1:100126442489:web:59823837dd4278d57df328"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore
const firestore = getFirestore(app);

// Initialize Firebase Authentication with persistence
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage)
});

export { firestore, auth };

