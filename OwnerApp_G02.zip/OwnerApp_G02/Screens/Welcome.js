import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import COLORS from '../colors'; // Ensure COLORS contains the color values you want to use

const WelcomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <View style={styles.imageWrapper}>
        <Image
          source={require('../assets/hero1.png')}
          style={styles.image}
        />
        <Image
          source={require('../assets/hero2.webp')}
          style={styles.image}
        />
        
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.heading}>Let's Get Started</Text>
        <Text style={styles.subHeading}>Welcome to Our App!! Where Luxury Meets Your Journey</Text>
      </View>
      <TouchableOpacity 
        style={styles.button} 
        onPress={() => navigation.navigate('Login')}
      >
        <Text style={styles.buttonText}>Get Started</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.primary, // Use a solid color as background
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  imageWrapper: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '50%', // Adjust height as needed
    marginBottom: 20,
  },
  image: {
    height: 100,
    width: 100,
    borderRadius: 20,
    margin: 10,
  },
  textContainer: {
    paddingHorizontal: 22,
    position: 'absolute',
    top: '40%', // Adjust based on the content
    width: '100%',
    alignItems: 'center', // Center the text horizontally
  },
  heading: {
    fontSize: 40, // Adjust font size as needed
    fontWeight: 'bold',
    color: COLORS.white,
    textAlign: 'center', // Center the text
  },
  subHeading: {
    fontSize: 20, // Adjust font size as needed
    fontWeight: 'normal',
    color: COLORS.white,
    textAlign: 'center', // Center the text
    marginVertical: 10,
  },
  button: {
    backgroundColor: 'white',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginTop: 20,
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    textAlign: 'center',
  },
});

export default WelcomeScreen;
