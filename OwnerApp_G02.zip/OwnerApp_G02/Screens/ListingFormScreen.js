import React, { useState, useEffect } from 'react';
import { View, TextInput, TouchableOpacity, Text, Image, ScrollView, StyleSheet, Alert } from 'react-native';
import { firestore, auth } from '../firebase-config';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';

const ListingFormScreen = () => {
  const [vehicleData, setVehicleData] = useState([]);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [vehicleName, setVehicleName] = useState('');
  const [vehiclePhoto, setVehiclePhoto] = useState('');
  const [seatingCapacity, setSeatingCapacity] = useState('');
  const [additionalProp1, setAdditionalProp1] = useState('');
  const [additionalProp2, setAdditionalProp2] = useState('');
  const [licensePlate, setLicensePlate] = useState('');
  const [pickupLocation, setPickupLocation] = useState('');
  const [rentalPrice, setRentalPrice] = useState('');
  const [user, setUser] = useState(null);

  const fetchVehicleData = async () => {
    try {
      const response = await fetch('https://wjessica021.github.io/group2/vehicles.json');
      const data = await response.json();
      console.log('Fetched vehicle data:', data);
      setVehicleData(data);
    } catch (error) {
      console.error('Error fetching vehicle data:', error);
      Alert.alert('Error', 'Failed to fetch vehicle data');
    }
  };

  useEffect(() => {
    fetchVehicleData();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return unsubscribe;
  }, []);

  const prepopulateForm = (vehicle) => {
    setVehicleName(`${vehicle.make} ${vehicle.model} ${vehicle.trim}`);
    setVehiclePhoto(vehicle.images[0].url_full);
    setSeatingCapacity(vehicle.seats_max.toString());
    setAdditionalProp1(vehicle.fuel);
    setAdditionalProp2(vehicle.drivetrain);
  };

  const handleSave = async () => {
    if (!user) {
      Alert.alert('Error', 'You must be logged in to save a listing.');
      return;
    }

    try {
      await addDoc(collection(firestore, 'rentals'), {
        vehicleName,
        vehiclePhoto,
        seatingCapacity,
        additionalProp1,
        additionalProp2,
        licensePlate,
        pickupLocation,
        rentalPrice,
        createdAt: serverTimestamp(),
        userId: user.uid,
      });
      Alert.alert('Success', 'Listing saved successfully!');
    } catch (error) {
      console.error('Error saving listing: ', error);
      Alert.alert('Error', 'Failed to save listing.');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.formSection}>
        <Text style={styles.label}>Select your vehicle:</Text>
        {vehicleData.length > 0 ? (
          vehicleData.map((vehicle, index) => (
            <TouchableOpacity key={index} style={styles.vehicleButton} onPress={() => prepopulateForm(vehicle)}>
              <Text style={styles.vehicleButtonText}>{vehicle.display_name}</Text>
            </TouchableOpacity>
          ))
        ) : (
          <Text style={styles.noVehiclesText}>No vehicles available</Text>
        )}
      </View>
      <View style={styles.formSection}>
        <Text style={styles.label}>Vehicle Name:</Text>
        <TextInput style={styles.input} value={vehicleName} onChangeText={setVehicleName} />
      </View>
      <View style={styles.formSection}>
        <Text style={styles.label}>Vehicle Photo:</Text>
        {vehiclePhoto ? <Image source={{ uri: vehiclePhoto }} style={styles.image} /> : null}
      </View>
      <View style={styles.formSection}>
        <Text style={styles.label}>Seating Capacity:</Text>
        <TextInput style={styles.input} value={seatingCapacity} onChangeText={setSeatingCapacity} keyboardType="numeric" />
      </View>
      <View style={styles.formSection}>
        <Text style={styles.label}>Additional Property 1 (Fuel Type):</Text>
        <TextInput style={styles.input} value={additionalProp1} onChangeText={setAdditionalProp1} />
      </View>
      <View style={styles.formSection}>
        <Text style={styles.label}>Additional Property 2 (Drivetrain):</Text>
        <TextInput style={styles.input} value={additionalProp2} onChangeText={setAdditionalProp2} />
      </View>
      <View style={styles.formSection}>
        <Text style={styles.label}>License Plate:</Text>
        <TextInput style={styles.input} value={licensePlate} onChangeText={setLicensePlate} />
      </View>
      <View style={styles.formSection}>
        <Text style={styles.label}>Pickup Location:</Text>
        <TextInput style={styles.input} value={pickupLocation} onChangeText={setPickupLocation} />
      </View>
      <View style={styles.formSection}>
        <Text style={styles.label}>Rental Price:</Text>
        <TextInput style={styles.input} value={rentalPrice} onChangeText={setRentalPrice} keyboardType="numeric" />
      </View>
      <TouchableOpacity style={styles.button} onPress={handleSave}>
        <Text style={styles.buttonText}>Save Listing</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#f5f5f5', // Light grey background
  },
  formSection: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333',
  },
  input: {
    height: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 12,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginBottom: 12,
  },
  vehicleButton: {
    backgroundColor: '#FFCCCB', // Light pink background for vehicle buttons
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  vehicleButtonText: {
    color: '#D36C6C', // Darker pink text for better contrast
    fontSize: 16,
    fontWeight: 'bold',
  },
  noVehiclesText: {
    textAlign: 'center',
    color: '#888',
  },
  button: {
    backgroundColor: '#FFCCCB', // Light pink background for Save button
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#D36C6C', // Darker pink text for better contrast
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ListingFormScreen;
