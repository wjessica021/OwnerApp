import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase-config';

const HomeScreen = ({ navigation }) => {
  const handleLogout = () => {
    signOut(auth).then(() => {
      navigation.replace('Login');
    });
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/hero6.jpg')} // Replace with your image path
        style={styles.headerImage}
      />
      <Text style={styles.headerText}>Welcome to Your Dashboard</Text>
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Create Listing')}>
          <Text style={styles.buttonText}>Create a New Listing</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Manage Bookings')}>
          <Text style={styles.buttonText}>Manage Bookings</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonLogout} onPress={handleLogout}>
          <Text style={styles.buttonTextLogout}>Logout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#e8f5e9', // Soft pastel green background
  },
  headerImage: {
    width: '100%',
    height: 180,
    marginBottom: 20,
    borderRadius: 10, // Rounded corners for the image
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#333',
    marginBottom: 30,
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  button: {
    backgroundColor: '#000', // Black background
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonLogout: {
    backgroundColor: '#d32f2f', // Dark red background for logout button
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff', // White text
    fontSize: 18,
    fontWeight: 'bold',
  },
  buttonTextLogout: {
    color: '#fff', // White text for logout button
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default HomeScreen;
