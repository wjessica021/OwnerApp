
import React, { useState, useEffect } from 'react';
import { View, Text, Button, FlatList, StyleSheet, Image } from 'react-native';
import { collection, query, where, getDocs, doc, updateDoc } from 'firebase/firestore';
import { auth, firestore } from '../firebase-config';
import COLORS from '../colors';

const ManageBookingsScreen = ({ navigation }) => {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBookings = async () => {
      const user = auth.currentUser;
      if (user) {
        try {
          const q = query(collection(firestore, 'rentals'), where('userId', '==', user.uid));
          const querySnapshot = await getDocs(q);
          const fetchedBookings = [];

          for (const docSnap of querySnapshot.docs) {
            const bookingData = docSnap.data();
            const renterQuery = query(collection(firestore, 'renters'), where('renterId', '==', bookingData.userId));
            const renterSnapshot = await getDocs(renterQuery);
            const renterData = renterSnapshot.docs[0]?.data();

            if (renterData) {
              fetchedBookings.push({ id: docSnap.id, ...bookingData, renter: renterData });
            } else {
              console.warn(`Renter not found for booking ID: ${docSnap.id}`);
            }
          }

          setBookings(fetchedBookings);
        } catch (error) {
          console.error('Error fetching bookings:', error);
          setError(error.message);
        }
      }
    };

    fetchBookings();
  }, []);

  const handleApprove = async (bookingId) => {
    try {
      const confirmationCode = Math.random().toString(36).substring(2, 15);
      const bookingRef = doc(firestore, 'rentals', bookingId);
      await updateDoc(bookingRef, {
        status: 'Approved',
        confirmationCode,
      });
      setBookings((prevBookings) =>
        prevBookings.map((booking) =>
          booking.id === bookingId ? { ...booking, status: 'Approved', confirmationCode } : booking
        )
      );
    } catch (error) {
      console.error('Error approving booking:', error);
    }
  };

  const handleDecline = async (bookingId) => {
    try {
      const bookingRef = doc(firestore, 'rentals', bookingId);
      await updateDoc(bookingRef, {
        status: 'Declined',
      });
      setBookings((prevBookings) =>
        prevBookings.map((booking) =>
          booking.id === bookingId ? { ...booking, status: 'Declined' } : booking
        )
      );
    } catch (error) {
      console.error('Error declining booking:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Image source={require('../assets/heroo.webp')} style={styles.heroImage} />
      {error && <Text style={styles.error}>{error}</Text>}
      <FlatList
        data={bookings}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.bookingItem}>
            <Image source={{ uri: item.vehiclePhoto }} style={styles.vehicleImage} />
            <Text style={styles.vehicleName}>{item.vehicleName}</Text>
            <Text style={styles.text}>License Plate: {item.licensePlate}</Text>
            <Text style={styles.text}>Price: {item.rentalPrice}</Text>
            <View style={styles.renterInfo}>
              <Image source={{ uri: item.renter?.renterPhoto }} style={styles.renterPhoto} />
              <Text style={styles.text}>Renter: {item.renter?.renterName}</Text>
              <Text style={styles.text}>Email: {item.renter?.email}</Text>
            </View>
            <Text style={styles.text}>Booking Date: {item.createdAt ? item.createdAt.toDate().toDateString() : 'N/A'}</Text>
            <Text style={styles.text}>Status: {item.status}</Text>
            {item.status === 'Needs Approval' && (
              <View style={styles.buttonsContainer}>
                <Button
                  title="Approve"
                  onPress={() => handleApprove(item.id)}
                  color="#90ee90" // Light green color for button
                />
                <Button
                  title="Decline"
                  onPress={() => handleDecline(item.id)}
                  color="#ffcccb" // Light pink color for button
                />
              </View>
            )}
            {item.status === 'Approved' && (
              <Text style={styles.text}>Confirmation Code: {item.confirmationCode}</Text>
            )}
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5', // Light grey background
  },
  heroImage: {
    width: '100%',
    height: 120,
    resizeMode: 'cover',
    marginBottom: 16,
  },
  bookingItem: {
    backgroundColor: '#fff',
    padding: 16,
    marginVertical: 8,
    marginHorizontal: 16,
    borderRadius: 8,
    elevation: 2, // Adds a shadow for better visibility on Android
  },
  vehicleImage: {
    width: '100%',
    height: 150,
    resizeMode: 'contain',
    marginBottom: 8,
  },
  vehicleName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    color: COLORS.primary,
  },
  text: {
    fontSize: 16,
    marginBottom: 4,
  },
  renterInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  renterPhoto: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 8,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  error: {
    color: 'red',
    marginBottom: 16,
  },
});

export default ManageBookingsScreen;
